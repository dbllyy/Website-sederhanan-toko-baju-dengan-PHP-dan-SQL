<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Kios Jersey | Deby Li</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <div class="header">
    <p>Kios Jersey | Deby Li</p>
  </div>
  <nav>
    <ul> <?php include("page/navbar.php") ?> </ul>
  </nav>

  <?php include("content.php") ?>

  <?php include("page/user/keranjang.php") ?>
  <div class="footer">
    <p>copyright by debyli(203130503108)  Repost by <a href="" target="_blank">Framework Id</a></p>
  </div>

</body>

</html>