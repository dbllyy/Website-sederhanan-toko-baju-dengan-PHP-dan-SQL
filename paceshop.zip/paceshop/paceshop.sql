/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.1.38-MariaDB : Database - paceshop
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`paceshop` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `paceshop`;

/*Table structure for table `tbl_barang` */

DROP TABLE IF EXISTS `tbl_barang`;

CREATE TABLE `tbl_barang` (
  `id_barang` int(100) NOT NULL AUTO_INCREMENT,
  `deskripsi` varchar(100) NOT NULL,
  `harga` int(20) NOT NULL,
  `stok` int(5) NOT NULL,
  `created` date NOT NULL,
  `nama_image` varchar(50) NOT NULL,
  `type_image` varchar(50) NOT NULL,
  `size_image` bigint(20) NOT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_barang` */

insert  into `tbl_barang`(`id_barang`,`deskripsi`,`harga`,`stok`,`created`,`nama_image`,`type_image`,`size_image`) values 
(1,'Jersey Barcelona HOME 2017/2018',145000,100,'2018-01-01','1.PNG','image/png',106168),
(2,'Jersey Real Madrid HOME 2017/2018',135000,50,'2018-01-01','3.png','image/png',85919),
(3,'Jersey Argentina HOME 2017/2018',120000,50,'2018-01-01','2.png','image/png',86296),
(4,'Jersey Liverpool HOME 2017/2018',135000,100,'2018-01-01','4.png','image/png',92477),
(5,'Jersey AC Milan HOME 2017/2018',130000,50,'2018-01-01','5.png','image/png',93559),
(6,'Jersey Manchester City HOME 2017/2018',145000,100,'2018-01-01','6.png','image/png',98904),
(7,'Jersey Bayern Munchen HOME 2017/2018',130000,50,'2018-01-01','7.png','image/png',99855),
(9,'Jersey Borusia Dortmund HOME 2017/2018',135000,100,'2023-03-17','8.png','image/png',135955);

/*Table structure for table `tbl_keranjang` */

DROP TABLE IF EXISTS `tbl_keranjang`;

CREATE TABLE `tbl_keranjang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `id_user` int(100) NOT NULL,
  `id_barang` int(100) NOT NULL,
  `ukuran` varchar(5) NOT NULL,
  `qty` int(50) NOT NULL,
  `kurir` varchar(15) NOT NULL,
  `date_in` date NOT NULL,
  `total` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_keranjang` */

insert  into `tbl_keranjang`(`id`,`id_user`,`id_barang`,`ukuran`,`qty`,`kurir`,`date_in`,`total`) values 
(1,7,7,'M',1,'JNE','2023-03-15',130000),
(7,2,6,'S',1,'JNE','2023-03-17',145000);

/*Table structure for table `tbl_pesanan` */

DROP TABLE IF EXISTS `tbl_pesanan`;

CREATE TABLE `tbl_pesanan` (
  `id_pesanan` int(100) NOT NULL AUTO_INCREMENT,
  `id_user` int(100) NOT NULL,
  `id_barang` int(100) NOT NULL,
  `ukuran` varchar(5) NOT NULL,
  `qty` int(50) NOT NULL,
  `kurir` varchar(15) NOT NULL,
  `date_in` date NOT NULL,
  `total` int(100) NOT NULL,
  PRIMARY KEY (`id_pesanan`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_pesanan` */

insert  into `tbl_pesanan`(`id_pesanan`,`id_user`,`id_barang`,`ukuran`,`qty`,`kurir`,`date_in`,`total`) values 
(19,2,9,'M',2,'JNE','2018-01-01',270000),
(23,2,2,'L',1,'TIKI','2023-03-17',135000),
(24,2,6,'M',1,'JNE','2023-03-17',145000),
(25,2,2,'M',3,'JNE','2023-03-17',405000);

/*Table structure for table `tbl_users` */

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `id_user` int(100) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(6) NOT NULL,
  `password` varchar(6) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_hp` text NOT NULL,
  `title` varchar(10) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_users` */

insert  into `tbl_users`(`id_user`,`nama_lengkap`,`email`,`username`,`password`,`alamat`,`no_hp`,`title`) values 
(1,'Deby Li','debyli@gmail.com','admin','admin','Jl. Piranha XXI A','082248080870','admin'),
(2,'Billy','Billy@gmail.com','billy','billy','JL RTA Milono','087877602333','user');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
