<div class="box-title">
    <p>Tentang / <b>Profil Pembuat</b></p>
</div>
<div id="box">

  <h1>Tentang</h1>
  <img src="img/debyli.jpeg" width="150" align="left"/>
  <table>
    <tr>
      <ul>
        <td width="25%">
          <li><b>NAMA</b></li>
        </td>
        <td>: Deby Li</td>
      </ul>
    </tr>

    <tr>
      <ul>
        <td>
          <li><b>NIM</b></li>
        </td>
        <td>: 203130503108</td>
      </ul>
    </tr>

    <tr>
      <ul>
        <td>
          <li><b>Jurusan</b></li>
        </td>
        <td>: S1 Teknik Informatika</td>
      </ul>
    </tr>

    <tr>
      <ul>
        <td>
          <li><b>Hobby</b></li>
        </td>
        <td>: Ngoding, Belajar bahasa pemrograman baru, Naik Gunung, Basket, Music play, dll</td>
      </ul>
    </tr>

    <tr>
      <ul>
        <td>
          <li><b>Minat</b></li>
        </td>
        <td>: I'M Web Developer, PHP addict, Full Stack Developer</td>
      </ul>
    </tr>

   

  </table>

</div>
